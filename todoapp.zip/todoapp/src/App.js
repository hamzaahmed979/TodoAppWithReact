import logo from "./logo.svg";
import "./App.css";
import Todoapp from "./Component/Todoapp";

function App() {
  return (
    <div>
      <Todoapp />
    </div>
  );
}

export default App;
