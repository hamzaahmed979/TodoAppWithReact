import React from "react";

class Todoapp extends React.Component {
  constructor() {
    super();
    this.state = {
      todo: [
        { title: "hamza", edit: false },
        { title: "ahmed", edit: false },
      ],
      value: "",
      edit: "",
    };
  }

  AddItem = () => {
    let obj = { title: this.state.value };
    this.setState({
      todo: [...this.state.todo, obj],
      value: "",
    });
  };

  delete_todo = (index) => {
    this.state.todo.splice(index, 1);

    this.setState({
      todo: this.state.todo,
    });
  };

  Delete_All = () => {
    this.setState({
      todo: [],
    });
  };

  edit_todo = (index, value) => {
    this.state.todo[index].edit = true;
    this.setState({
      todo: this.state.todo,
    });
  };

  handleChange = (e, index) => {
    this.state.todo[index].title = e.target.value;
    this.setState({
      todo: this.state.todo,
    });
    console.log(e.target.value);
  };
  Update_todo = (index) => {
    this.state.todo[index].edit = false;
    this.setState({
      todo: this.state.todo,
    });
  };
  render() {
    let { todo, value } = this.state;
    return (
      <div>
        <input
          value={value}
          type="text"
          onChange={(e) => this.setState({ value: e.target.value })}
        />
        <button onClick={this.Delete_All}>Delete All</button>
        <button onClick={this.AddItem}>Add item</button>
        <ul>
          {todo.map((v, i) => (
            <li key={i}>
              {v.edit ? (
                <input
                  value={v.title}
                  type="text"
                  onChange={(e) => this.handleChange(e, i)}
                />
              ) : (
                v.title
              )}
              {v.edit ? (
                <button onClick={() => this.Update_todo(i)}>Update</button>
              ) : (
                <button onClick={() => this.edit_todo(i, v.title)}>Edit</button>
              )}
              <button onClick={() => this.delete_todo(i)}>Delete</button>
            </li>
          ))}
        </ul>
      </div>
    );
  }
}

export default Todoapp;
